#!/bin/bash
# Modify from http://sobereva.com/258

# Your ORCA path
icc=0
nfile=`ls ./*.inp|wc -l`

output_file="molpro.csv"

echo "CASSCF,MRCI,MRCI+Q Davidson,MRCI+Q Davidson relaxed,MRCI+Q Pople,MRCI+Q Pople relaxed,ACPF,AQCC" > "$output_file"

for inf in *.inp ;do
((icc++))
    echo Running ${inf} ... \($icc of $nfile\)
    filename="${inf%.*}"
    time /home/usu171/chem2/mp/bin/molpro -n 8 ${inf} -I /dev/shm/molpro -d /dev/shm/molpro -W /dev/shm/molpro/w -m 1g

    awk '
/!MCSCF STATE 1.1 Energy/ {l1 = $5}
/!MRCI STATE 1.1 Energy/ {l2 = $5}
/Davidson, fixed reference/ {l3 = $4}
/Davidson, relaxed reference/ {l4 = $4}
/Pople, fixed reference/ {l5 = $4}
/Pople, relaxed reference/ {l6 = $4}
/!ACPF STATE 1.1 Energy/ {l7 = $5}
/!AQCC STATE 1.1 Energy/ {l8 = $5}
END {
printf "%s,%s,%s,%s,%s,%s,%s,%s\n", l1, l2, l3, l4, l5, l6, l7, l8
}
    ' "${inf/inp/out}" >> "$output_file"


    echo ${inf} has finished
done
