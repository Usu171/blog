#!/bin/bash
# Modify from http://sobereva.com/258

# Your ORCA path
orca_path=/home/usu171/chem/orca_5_0_4
icc=0
nfile=`ls ./*.inp|wc -l`

output_file="energy.csv"

echo "HF,UHF,MP2,UMP2,CCSD(T),UCCSD(T),CCD,UCCD,MP3,UMP3,QCISD(T),UQCISD(T),CISD,UCISD,MP4,UMP4,CASSCF,CASPT2,SC-NEVPT2,FIC-NEVPT2,MRCI,CCSD,UCCSD,QCISD,UQCISD,MRCI-1" > "$output_file"

for inf in *.inp ;do
((icc++))
    echo Running ${inf} ... \($icc of $nfile\)
    filename="${inf%.*}"
    time $orca_path/orca ${inf} > ${inf/inp/out}

    awk '
/E_HF/ {l1 = $2}
/E_UHF/ {l2 = $2}
/E_MP2/ {l3 = $2}
/E_UMP2/ {l4 = $2}
/E_CCSD_T/ {l5 = $2}
/E_UCCSD_T/ {l6 = $2}
/E_CCD/ {l7 = $2}
/E_UCCD/ {l8 = $2}
/E_MP3/ {l9 = $2}
/E_UMP3/ {l10 = $2}
/E_QCI/ {l11 = $2}
/E_UQCI/ {l12 = $2}
/E_CI/ {l13 = $2}
/E_UCI/ {l14 = $2}
/E_MP4/ {l15 = $2}
/E_UMP4/ {l16 = $2}
/E_CASSCF/ {l17 = $2}
END {
printf "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,", l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13, l14, l15, l16, l17
}
    ' "${inf/inp/out}" >> "$output_file"

paste -d "," \
    <(grep "FINAL SINGLE POINT ENERGY" "${inf/inp/out}" | tail -n 4 | awk '{print $5}' | paste -sd "," -) \
    <(grep "^E(CCSD)" "${inf/inp/out}" | awk '{print $3}' | paste -sd "," -) \
    <(grep "^E(QCISD)" "${inf/inp/out}" | awk '{print $3}' | paste -sd "," -) \
    <(grep "STATE   0:  Energy" "${inf/inp/out}" | head -n 1 | awk '{print $4}' | paste -sd "," -) >> $output_file

    rm $filename.densities $filename.gbw ${filename}_property.txt *Compound* *.bibtex *.bas* *.tmp
    echo ${inf} has finished
done
